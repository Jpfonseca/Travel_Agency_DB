﻿Imports System.Data.SqlClient
Public Class Configurar
    Dim CN As SqlConnection
    Public Sub New(ByRef sq As SqlConnection)
        CN = sq
        InitializeComponent()

        Dim command As SqlCommand = New SqlCommand("select * from udf_getPostosdeVenda()", CN)
        Dim reader As SqlDataReader = command.ExecuteReader()
        While reader.Read()
            ListBox1.Items.Add(reader(0))
        End While
        reader.Close()
        ' 
    End Sub
    Private Sub Configurar_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

    End Sub
End Class